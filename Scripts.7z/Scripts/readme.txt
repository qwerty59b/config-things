copia la carpeta scripts a C:\

el acceso directo que esta dentro de la carpeta scripts tienes que copiarlo, pero primero Win + R > shell:startup > Enter
se va a abrir una nueva ventana del explorer y ahi dentro es que tienes que pegar el acceso directo de la carpeta scripts reinicia o cierra sesion y listo cuando inicies sesion el script se va autoiniciar y cada ves que la ventana registro de idm se muestre se va a autocerrar



si desintalas idm o ya no quieres usar mas el script simplemente Win + R > shell:startup > Enter y elimina el acceso directo